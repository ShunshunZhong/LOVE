clear all;
close all;
clc;
inputfiles = '........';
patch.col = 30;
patch.row = 30;
patch.stepx = 10;
patch.stepy = 10;
for i= 1:6
 tic
 original_img = imread([inputfiles, num2str(i), '.bmp']);
 if size(original_img, 3) == 3
    original_img = rgb2gray(original_img);
 end
 original_img1 = double(original_img);
 aa=std(original_img1(:));
 gs = fspecial('gaussian',3,0.7);
 original_img = imfilter(original_img1, gs, 'symmetric');  
patch_img = acce_patch_model(original_img, patch);
dimension_num = size(patch_img);
row_patch = prod(dimension_num(1:2));
col_patch = dimension_num(3);
combine_2D = reshape(patch_img, [row_patch, col_patch]);
dimension_num = size(patch_img);
calculate_num = dimension_num(3);
 delta = 1e-7;
 [L_R,T_E,G,iter_num,iter_err] = acce_low_rank(combine_2D,delta);
  L_R = reshape(L_R,patch.col,patch.row,col_patch);
  L_R = acce_recovery_model(L_R,original_img,patch);
 T_E = reshape(T_E,patch.col,patch.row,col_patch);
 T_E = acce_recovery_model(T_E,original_img,patch);
 G = reshape(G,patch.col,patch.row,col_patch);
 G = acce_recovery_model(G,original_img,patch);
 I_edge = structure_tensor_calculate(L_R);
 T_A1 = T_E - 15.*I_edge;
 T_A1 = max(T_A1,0);
 toc;
 figure;
 imshow(T_E,[]); title('target');
end