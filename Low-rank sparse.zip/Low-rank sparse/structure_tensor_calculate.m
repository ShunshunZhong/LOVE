function [Ed_saliency_map] = structure_tensor_calculate(I_patch)
[Hig Wid]=size(I_patch);
lambda_1 =zeros(Hig,Wid);
lambda_2 =zeros(Hig,Wid);
[dx dy]=gradient(I_patch,2,2);
dx2=dx.^2;
dy2=dy.^2;
dxy=dx.*dy;
J_coor = zeros(Hig,Wid, 2, 2);  
K_g = fspecial('gaussian',3, 0.3); 
 J_coor(:,:,1,1) = imfilter(dx2, K_g, 'symmetric'); 
 J_coor(:,:,1,2) =  imfilter(dxy, K_g, 'symmetric');
 J_coor(:,:,2,1) = J_coor(:,:,1,2);
 J_coor(:,:,2,2) = imfilter(dy2, K_g, 'symmetric');
 delta_ac= J_coor(:,:,1,2).^2 -(J_coor(:,:,1,1).*J_coor(:,:,2,2));
 delta_ac = max(delta_ac,0);
 delta(:,:) = sqrt((J_coor(:,:,1,1) + J_coor(:,:,2,2)).^2 + 4 .* delta_ac);
 lambda_1(:,:) = 0.5*(J_coor(:,:,1,1) + J_coor(:,:,2,2) + delta(:,:));
 lambda_2(:,:)= 0.5*(J_coor(:,:,1,1) + J_coor(:,:,2,2) - delta(:,:));
lambda_diff = lambda_1 - lambda_2;
Ed_saliency_map = exp(0.5*mat2gray(lambda_diff));


