function I_image_recovery = acce_recovery_model(I_patch_edge_tesor,original_img,patch)
[m n]= size(original_img);
I_patch_edge_tesor = double(I_patch_edge_tesor);
[m1 n1 l1] = size(I_patch_edge_tesor);
step_x = patch.stepx;
step_y = patch.stepy;
sizerow = patch.row;
sizecol = patch.col;
row_collect_num = floor((m - sizerow)/step_y)+1;
col_collect_num = floor((n - sizecol)/step_x)+1;
row_patch_limt = [1:step_y:(row_collect_num - 1)*step_y, m - sizerow+1];
col_patch_limt = [1:step_x:(col_collect_num - 1)*step_x, n - sizecol+1];
L_row = length(row_patch_limt);
L_col = length(col_patch_limt);
R_img = zeros(m,n);
r_img = zeros(sizerow,sizerow);
num_patch = 1;
wei_num=zeros(m,n);
for i = 1:L_row
    for j = 1:L_col
       r_img = I_patch_edge_tesor(:,:,num_patch);
       R_img(row_patch_limt(i):row_patch_limt(i)+sizerow-1,col_patch_limt(j):col_patch_limt(j)+sizecol-1)=.............
       R_img(row_patch_limt(i):row_patch_limt(i)+sizerow-1,col_patch_limt(j):col_patch_limt(j)+sizecol-1)+r_img;
       wei_num(row_patch_limt(i):row_patch_limt(i)+sizerow-1,col_patch_limt(j):col_patch_limt(j)+sizecol-1)= ...........
       wei_num(row_patch_limt(i):row_patch_limt(i)+sizerow-1,col_patch_limt(j):col_patch_limt(j)+sizecol-1)+1;
       num_patch = num_patch+1;
    end
    
end
I_image_recovery =  R_img ./wei_num;



