function patch_img = acce_patch_model(original_img, patch)
M = [];
I_img = double(original_img);
[row col] = size(I_img);
step_x = patch.stepx;
step_y = patch.stepy;
sizerow = patch.row;
sizecol = patch.col;
row_collect_num = floor((row - sizerow)/step_y)+1;
col_collect_num = floor((col - sizecol)/step_x)+1;
row_patch_limt = [1:step_y:(row_collect_num - 1)*step_y, row - sizerow+1];
col_patch_limt = [1:step_x:(col_collect_num - 1)*step_x, col - sizecol+1];
L_row = length(row_patch_limt);
L_col = length(col_patch_limt);
cell_model = cell(L_row,L_col);
for i = 1:L_row
    for j = 1:L_col
 cell_model{i,j} = I_img(row_patch_limt(i):row_patch_limt(i)+sizerow-1,col_patch_limt(j):col_patch_limt(j)+sizecol-1);
    end
end 
cell_model = cell_model';
M = cat(3,cell_model{:});
patch_img = M;

