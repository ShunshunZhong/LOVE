function [L_R, T_E,G,iter_num,calcu_err]=acce_low_rank(LR_SP,delta)
r = 17;
q = 1; 
sigma = std(LR_SP(:));
flag = true;
iter_max=1000;
calcu_err=[];
T_E = ones(size(LR_SP)); 
L_R = LR_SP;
[m,n]=size(LR_SP);
    iter_num= 1;
    Y2=randn(n,r);
    while flag
       G =T_E -  T_E .* (1./((1+((T_E.*T_E)./(sigma.*sigma)).^2).^3));
        X1=LR_SP-G;
            %Update low-rank L_R
            for i=1:q+1
                Y1=X1*Y2;
                Y2=X1'*Y1;
            end
            [Q2,R2]=qr(Y2,0);
           [Q1,R1]=qr(Y1,0);
           base=(R1* (pinv(Y1'*Y1)*R2'));
           base= real(base);
           L_R_updata =Q1*base*Q2';
           Y2 = Q2;
           T_E = LR_SP - L_R_updata;
       
        L_diff = L_R_updata - L_R;
        stop_culcu = (norm(L_diff(:))/norm(L_R(:)))^2;
        calcu_err = [calcu_err,stop_culcu];

        if stop_culcu < delta || iter_num >iter_max
           flag = false;
        end

        L_R = L_R_updata;
        iter_num = iter_num + 1;
    end
    L_R = L_R_updata;
 
